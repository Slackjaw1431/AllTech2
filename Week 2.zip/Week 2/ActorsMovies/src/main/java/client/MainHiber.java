package client;

import org.hibernate.Session;
import org.hibernate.Transaction;

import entity.Actor;
import entity.Movie;
import util.HibernateUtil;

public class MainHiber {

	public static void main(String[] args) {
		Session session = HibernateUtil.buildSessionFactory().openSession();
		Transaction txn = session.getTransaction();
		try {
			txn.begin();
			
			Movie movie = new Movie("Die Hard");
			Actor actor = new Actor("Bruce_Willis");
			
			movie.getActors().add(actor);
			
			session.persist(movie);
			
			txn.commit();

		} catch (Exception e) {
			if (txn != null) {
				txn.rollback();
				e.printStackTrace();
				}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

}
