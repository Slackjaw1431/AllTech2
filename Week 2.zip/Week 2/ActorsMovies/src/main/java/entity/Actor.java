package entity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;

@Entity
public class Actor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID")
	private Long id;
	private String name;
	@ManyToMany(mappedBy="actors")
	private Set<Movie> movies = new HashSet<Movie>();

	public Actor() {

	}

	public Actor(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Movie> getMovies() {
		return movies;
	}

	public void setMovies(Set<Movie> movies) {
		this.movies = movies;
	}
	
	public void addMovie(Movie m) {
		this.movies.add(m);
		m.getActors().add(this);
	}
	
	public void removeMovie(Movie m) {
		this.movies.remove(m);
		m.getActors().remove(this);
	}

}
