package products;

import java.sql.SQLException;

public interface ProductDAOInterface {
	
	public void getAllProducts();
	public Product addProduct(Product p);
	public Product updateProduct(int prodID, String name, int prodPrice);
	public Product readProduct(String ID) throws SQLException;
	public Product deleteProduct(String ID);

}
