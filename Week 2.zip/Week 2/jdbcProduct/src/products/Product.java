package products;

public class Product {

	private int prodID;
	private String name;
	private int prodPrice;

	public Product() {
	}

	public Product(int prodId, String name,
			int bookPrice) {
		this.prodID = prodId;
		this.name = name;
		this.prodPrice = bookPrice;
	}

	public int getProdId() {
		return prodID;
	}

	public void setProdId(int prodId) {
		this.prodID = prodId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getProdPrice() {
		return prodPrice;
	}

	public void setProdPrice(int prodPrice) {
		this.prodPrice = prodPrice;
	}

	@Override
	public String toString() {
		return "Product [prodId=" + prodID + ", name="
				+ name + ", bookPrice=" + prodPrice + "]";
	}

}
