package products;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductDAOImp implements ProductDAOInterface {

	private static String QUERY = "";
	private static Connection connection = null;
	private static java.sql.Statement stmt = null;
	private static ResultSet rs = null;

	@Override
	public void getAllProducts() {
		try {
			QUERY = "SELECT * FROM products";

			connection = JDBCUtil.getConnection();
			stmt = connection.createStatement();
			rs = stmt.executeQuery(QUERY);
			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString("prod_name");
				int salary = rs.getInt("prod_price");
				System.out.println(
						id + " " + name + " " + salary);
			}
			try {
				connection.close();
				rs.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public Product addProduct(Product p) {
		QUERY = "INSERT INTO products Values (?,?,?)";

		try {
			connection = JDBCUtil.getConnection();

			PreparedStatement ps = connection
					.prepareStatement(QUERY);

			ps.setInt(1, p.getProdId());
			ps.setString(2, p.getName());
			ps.setInt(3, p.getProdPrice());
			int i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("Product added");
			} else {
				System.out.println("Failed to add product");
			}
			ps.close();
			connection.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		return null;
	}

	@Override
	public Product readProduct(String ID)
			throws SQLException {
		QUERY = "SELECT * FROM products WHERE prod_id = ?";

		connection = JDBCUtil.getConnection();
		PreparedStatement ps = connection
				.prepareStatement(QUERY);
		ps.setString(1, ID);// column number, id
		rs = ps.executeQuery();

		if (rs.next()) {
			int id1 = rs.getInt("prod_id");
			String name = rs.getString("prod_name");
			int price = rs.getInt("prod_price");
			System.out.println(
					id1 + " " + name + " " + price);
			try {
				connection.close();
				rs.close();
				ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("Invalid Product ID");
		}
		return null;
	}

	@Override
	public Product deleteProduct(String ID) {
		QUERY = "Delete FROM products WHERE prod_id = ?";

		try {
			connection = JDBCUtil.getConnection();

			PreparedStatement ps = connection
					.prepareStatement(QUERY);
			ps.setString(1, ID);// column number, id
			int i = ps.executeUpdate();

			if (i > 0) {
				System.out.println("Data deleted");
				connection.close();
				ps.close();
			} else {
				System.out.println("Invalid Product ID");
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return null;
	}

	@Override
	public Product updateProduct(int prodID, String name,
			int prodPrice) {

		QUERY = "UPDATE products SET prod_name = ?, prod_price = ? WHERE prod_id = ?";

		try {
			connection = JDBCUtil.getConnection();

			PreparedStatement ps = connection
					.prepareStatement(QUERY);

			ps.setString(1, name);
			ps.setInt(2, prodPrice);
			ps.setInt(3, prodID);

			int i = ps.executeUpdate();

			if (i > 0) {
				System.out.println("Product updated");
			} else {
				System.out.println(
						"Failed to update Product");
			}
			ps.close();
			connection.close();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		return null;
	}

}
