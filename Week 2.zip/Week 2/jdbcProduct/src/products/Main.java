package products;

import java.sql.SQLException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		ProductDAOInterface dao = new ProductDAOImp();
		Product p;

		Scanner scan = new Scanner(System.in);
		int count = 0;

		while (count != 5) {
			System.out.println("------------------------");
			System.out.println("1. Create Product");
			System.out.println("2. Read Product Data");
			System.out.println("3. Update Product Data");
			System.out.println("4. Delete Product");
			System.out.println("5. Exit");
			System.out.println("------------------------");
			count = scan.nextInt();

			if (count == 1) {
				System.out.println("Add id: ");
				int id = scan.nextInt();
				System.out.println("Add name: ");
				String name = scan.next();
				System.out.println("Add price: ");
				int price = scan.nextInt();
				p = new Product(id, name, price);
				dao.addProduct(p);
				count = 0;

			}

			else if (count == 2) {
				System.out
						.println("Enter prod ID to read: ");
				String prodID = scan.next();
				try {
					p = dao.readProduct(prodID);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				count = 0;

			} else if (count == 3) {
				System.out.println(
						"Enter prod ID to update: ");
				int prodID = scan.nextInt();
				System.out.println("Enter new emp name: ");
				String name = scan.next();
				System.out.println(
						"Enter new prod price: ");
				int prodPrice = scan.nextInt();
				p = dao.updateProduct(prodID, name, prodPrice);
				count = 0;

			} else if (count == 4) {
				System.out.println(
						"Enter prod ID to delete: ");
				String prodID = scan.next();
				dao.deleteProduct(prodID);
				count = 0;

			} else if (count == 5) {
				System.out.println("Exiting");
				System.exit(0);
			} else {
				count = scan.nextInt();
			}

		}
	}

}
