package products;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCUtil {
	
	private static String jdbcUrl="jdbc:mysql://localhost:3306/productsJDBC";
	private static String jdbcUsername="root";
	private static String jdbcPassword="password";


	public static Connection getConnection() {
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(jdbcUrl,jdbcUsername,jdbcPassword);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return connection;
	} 

}
