package com.products;

public interface ProductDAOInterface {
	
	void addProduct();
	void updateProduct();
	void readProduct();
	void deleteProduct();

}
