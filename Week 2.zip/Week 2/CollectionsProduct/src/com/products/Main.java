package com.products;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		ProductDAOImp productsStore = new ProductDAOImp();

		Scanner scan = new Scanner(System.in);
		int input = 0;

		while (input != 5) {
			menu();
			input = scan.nextInt();

			if (input == 1) {
				productsStore.addProduct();

			} else if (input == 2) {
				productsStore.readProduct();
			} else if (input == 3) {
				productsStore.updateProduct();

			} else if (input == 4) {
				productsStore.deleteProduct();
			} else {

			}
		}

	}

	public static void menu() {
		System.out.println("1. Add Product");
		System.out.println("2. Get Product by ID");
		System.out.println("3. Update Product by ID");
		System.out.println("4. Delete Product by ID");
		System.out.println("5. Exit");
	}

}
