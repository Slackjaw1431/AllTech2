package com.products;

public class Product {

	private int prodID;
	private String name;
	private float prodPrice;

	public Product() {
	}

	public Product(int prodId, String name,
			float bookPrice) {
		this.prodID = prodId;
		this.name = name;
		this.prodPrice = bookPrice;
	}

	public int getProdId() {
		return prodID;
	}

	public void setProdId(int prodId) {
		this.prodID = prodId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getProdPrice() {
		return prodPrice;
	}

	public void setProdPrice(float prodPrice) {
		this.prodPrice = prodPrice;
	}

	@Override
	public String toString() {
		return "Product [prodId=" + prodID + ", name="
				+ name + ", bookPrice=" + prodPrice + "]";
	}

}
