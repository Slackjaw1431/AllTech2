package com.products;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ProductDAOImp implements ProductDAOInterface {

	private List<Product> products;

	public ProductDAOImp() {
		products = new ArrayList<>();
	}

	@Override
	public void addProduct() {
		Product prod = new Product();
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter product id:");
		int prodID = scan.nextInt();
		prod.setProdId(prodID);
		System.out.println("Enter product name:");
		String name = scan.next();
		prod.setName(name);
		System.out.println("Enter product price:");
		float price = scan.nextFloat();
		prod.setProdPrice(price);
		products.add(prod);

	}

	@Override
	public void updateProduct() {
		System.out.println("Enter product id to read:");
		Scanner scan = new Scanner(System.in);
		int id = scan.nextInt();
		boolean found = false;

		for (int i = 0; i < products.size(); i++) {
			Product prod = (Product) products.get(i);
			if (prod.getProdId() == id) {
				found = true;
				System.out
						.println("Enter new product name:");
				String name = scan.next();
				prod.setName(name);
				System.out.println(
						"Enter new product price:");
				float price = scan.nextFloat();
				prod.setProdPrice(price);
				break;
			}
		}
		if (found) {

		} else {
			System.out.println("Product ID not found");
		}
	}

	@Override
	public void readProduct() {
		System.out.println("Enter product id to read:");
		Scanner scan = new Scanner(System.in);
		int id = scan.nextInt();
		boolean found = false;

		for (int i = 0; i < products.size(); i++) {
			Product prod = products.get(i);
			if (prod.getProdId() == id) {
				found = true;
				System.out.println(prod.toString());
				break;
			}
		}
		if (found) {

		} else {
			System.out.println("Product ID not found");
		}

	}

	@Override
	public void deleteProduct() {
		System.out.println("Enter product id to delete:");
		Scanner scan = new Scanner(System.in);
		int id = scan.nextInt();
		boolean found = false;

		for (int i = 0; i < products.size(); i++) {
			Product prod = (Product) products.get(i);
			if (prod.getProdId() == id) {
				found = true;
				products.remove(prod);
				break;
			}
		}
		if (found) {

		} else {
			System.out.println("Product ID not found");
		}

	}

}
