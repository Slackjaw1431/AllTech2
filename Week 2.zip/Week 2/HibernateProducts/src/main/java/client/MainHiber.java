package client;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import domain.Product;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import util.HibernateUtil;

public class MainHiber {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		int count = 0;

		while (count != 6) {
			System.out.println("------------------------");
			System.out.println("1. Create Product");
			System.out.println("2. Read Product Data");
			System.out.println("3. Update Product Data");
			System.out.println("4. Delete Product");
			System.out.println("5. Get all Products");
			System.out.println("6. Exit");
			System.out.println("------------------------");
			count = scan.nextInt();

			if (count == 1) {
				System.out.println("Enter Product title:");
				String name = scan.next();
				System.out.println("Enter Product price:");
				int price = scan.nextInt();
				Product product = new Product(name, price);
				insert(product);
				count = 0;

			}

			else if (count == 2) {
				System.out.println("Enter Product id:");
				Long id = scan.nextLong();
				read(id);

				count = 0;

			} else if (count == 3) {
				System.out.println("Enter Product id:");
				Long id = scan.nextLong();
				System.out.println("Enter new Product name:");
				String newTitle = scan.next();
				System.out.println("Enter new Product prce:");
				int newPrice = scan.nextInt();
				update(id, newTitle, newPrice);

				count = 0;

			} else if (count == 4) {
				System.out.println("Enter Product id:");
				Long id = scan.nextLong();
				delete(id);

				count = 0;

			} else if (count == 5) {
				getAllProducts();

				count = 0;
			} else if (count == 6) {
				System.out.println("Exiting");
				System.exit(0);
			} else {
				count = scan.nextInt();
			}
		}

	}

	private static void getAllProducts() {
		Session session = HibernateUtil.buildSessionFactory().openSession();
		Transaction txn = session.getTransaction();

		try {
			txn.begin();

			CriteriaBuilder builder = session.getCriteriaBuilder();
			CriteriaQuery<Product> criteria = builder.createQuery(Product.class);
			criteria.from(Product.class);
			List<Product> products = session.createQuery(criteria).getResultList();

			for (Product product : products) {
				System.out.println(product.toString());
			}

		} catch (Exception e) {
			if (txn != null) {
				txn.rollback();
				System.out.println("Product not found");
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	private static void insert(Product product) {
		try{
			Session session = HibernateUtil.buildSessionFactory().openSession();
			session.beginTransaction();
			session.persist(product);
			session.getTransaction().commit();
			session.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	private static void read(Long id) {
		Session session = HibernateUtil.buildSessionFactory().openSession();
		Transaction txn = session.getTransaction();

		try {
			txn.begin();
			Product product = (Product) session.get(Product.class, id);
			System.out.println(product.toString());

		} catch (Exception e) {
			if (txn != null) {
				txn.rollback();
				System.out.println("Product not found");
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	private static void update(Long id, String newName, int newPrice) {
		Session session = HibernateUtil.buildSessionFactory().openSession();
		Transaction txn = session.getTransaction();

		try {
			txn.begin();
			Product product = (Product) session.get(Product.class, id);
			product.setProdName(newName);
			product.setProdPrice(newPrice);
			txn.commit();
			System.out.println("Product updated");

		} catch (Exception e) {
			if (txn != null) {
				txn.rollback();
				System.out.println("Unable to update");
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	private static void delete(Long id) {
		Session session = HibernateUtil.buildSessionFactory().openSession();
		Transaction txn = session.getTransaction();

		try {
			txn.begin();
			Product product = (Product) session.get(Product.class, id);
			session.remove(product);
			txn.commit();
			System.out.println("Product removed");

		} catch (Exception e) {
			if (txn != null) {
				txn.rollback();
				System.out.println("Unable to delete");
			}
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

}
